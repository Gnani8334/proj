package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Cart;
import com.capgemini.flp.service.CartServiceInterface;



public class CartController {
@Autowired
CartServiceInterface cartService;
@RequestMapping(value="/cartdetails",method=RequestMethod.GET)
public ModelAndView getAllCartdetails(@ModelAttribute("cart") Cart cart){
	cart.setSessionId(24755);
	/*List<SessionSchedule> allSessionsList=sessionservice.getSessionSchedule();
	System.out.println(allSessionsList);	//to check whether list is obtained or not. it displays list in console											
	*/
	
	return new ModelAndView("abc", "data", abc);
}
	
	
@RequestMapping(value="/cartdetails",method=RequestMethod.GET)
public List getProductDetails() {
	 String email_Id="abc@gmail.com";
	 int product_Id=1;
	 List list=	 cartService.getProductDetails(email_Id,product_Id);
return list;
}
}
