package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NamedQuery;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.capgemini.flp.dto.Admin;

public class CartDaoImpl implements CartDaoInterface {
@PersistenceContext
EntityManager entityManager;

@Override
public List<Admin> getProductDetails(String email_Id, int product_Id) {
	// TODO Auto-generated method stub
	Query query= entityManager.createQuery("select productId,product_Name,product_Description,product_Category,product_price,Quantity,seller_emailId where productId=product_Id and FROM Admin");
	List<Admin> list=query.getResultList();
	Query query1= entityManager.createQuery("select email_Id from Customer");
	String emailId=(String) query1.getSingleResult();
	Query query2= entityManager.createQuery("INSERT INTO Cart(productId,product_Name,product_Description,product_Category,product_price,Quantity,seller_emailId)SELECT(productId,product_Name,product_Description,product_Category,product_price,Quantity,seller_emailId)FROM "
    Admin where productId=product_Id"; 


  

     
	//return list;
}

	
}
