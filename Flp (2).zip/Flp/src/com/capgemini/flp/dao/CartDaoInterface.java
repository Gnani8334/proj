package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Admin;

public interface CartDaoInterface {
public List<Admin> getProductDetails(String email_Id, int product_Id);

}
