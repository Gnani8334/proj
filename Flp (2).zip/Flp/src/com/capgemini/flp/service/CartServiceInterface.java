package com.capgemini.flp.service;

import java.util.List;

public interface CartServiceInterface {

	List getProductDetails(String email_Id, int product_Id);

}
