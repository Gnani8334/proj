package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.flp.dao.CartDaoInterface;

public class CartServiceImpl implements CartServiceInterface {
@Autowired
CartDaoInterface cartDao;
	@Override
	public List getProductDetails(String email_Id, int product_Id) {
		// TODO Auto-generated method stub
		return cartDao.getProductDetails(email_Id,product_Id);
	}

}
