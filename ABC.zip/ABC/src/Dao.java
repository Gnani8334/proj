import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class Dao {
	@PersistenceContext
	EntityManager em;
Cart c=new Cart();

	
	public boolean  remove(int customerId) {
		// TODO Auto-generated method stub
 c=	em.find(Cart.class,customerId);
em.remove(c);
	//	Query query=em.createNamedQuery("DELETE FROM Cart WHERE customerId= customerId");
	return true;
	}

}
