import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


public class Controller {
	@Autowired
	Service service;
	
	@RequestMapping(value="deletemodule")
	public void delete(@RequestParam("customerId") int CustomerId)
	{
		service.remove(CustomerId);
	}

}
