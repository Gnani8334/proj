import org.springframework.beans.factory.annotation.Autowired;

public class Service {
@Autowired
Dao dao;
public void remove(int CustomerId)
{
	dao.remove(CustomerId);

}

}
