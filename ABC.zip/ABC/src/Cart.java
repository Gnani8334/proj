import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
int customerId;
String productName;
@Override
public String toString() {
	return "Cart [customerId=" + customerId + ", productName=" + productName + "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public Cart(int customerId, String productName) {
	super();
	this.customerId = customerId;
	this.productName = productName;
}
public Cart() {
	super();
}
}
